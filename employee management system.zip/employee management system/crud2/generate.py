import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','crud2.settings')

import django
django.setup()

from crudApp.models import*
from faker import Faker
from random import *
Faker=Faker()

def generate(n):
    for i in range(n):
        feno=randint(1001,9999)
        fename=Faker.name()
        fephone=randint(1000,9999)
        feage=randint(20,35)
        feadd=Faker.city()
        employeeRrecord=Employee.objects.get_or_create(eno=feno,ename=fename,ephone=fephone,eage=feage,eadd=feadd)
generate(30)
