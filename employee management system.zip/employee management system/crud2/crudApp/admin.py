from django.contrib import admin
from crudApp.models import Employee

# Register your models here.
class EmployeeAdmin(admin.ModelAdmin):
    list=['eno','ename','ephone','eage','eadd']
admin.site.register(Employee,EmployeeAdmin)
