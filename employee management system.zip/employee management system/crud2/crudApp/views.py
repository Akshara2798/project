from django.shortcuts import render,redirect
from crudApp.models import Employee
from crudApp.forms import EmployeeForm
from django.contrib import messages

# Create your views here.
def index(request):
    return render(request,'crudApp/home.html')
def retrive(request):
    employee=Employee.objects.all()
    return render(request,'crudApp/index.html',{'employee':employee})

def create(request):
    form=EmployeeForm()
    if request.method=='POST':
        form=EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/home')
    return render(request,'crudApp/form.html',{'form':form})


def delete(request,id):
    employee=Employee.objects.get(id=id)
    employee.delete()
    return redirect('/home')

def update(request,id):
    employee=Employee.objects.get(id=id)
    if request.method=='POST':
        number=request.POST['no']
        name=request.POST['name']
        phone=request.POST['phone']
        age=request.POST['age']
        address=request.POST['address']

        employee.eno=number
        employee.ename=name
        employee.ephone=phone
        employee.eage=age
        employee.eadd=address
        employee.save()
        messages.success(request,"update done")
        return redirect('/home')
    return render(request,'crudApp/update.html',{'employee':employee})





